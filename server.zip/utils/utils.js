const toLowerCase = (val) => {
  if (val) return val.toLowerCase();
  else return val;
};

module.exports = toLowerCase;

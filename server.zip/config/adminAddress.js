const AdminAddresses = ["0x870cfa0f8D013A4C84eF026B3414ee06F2BE8121"];

module.exports = AdminAddresses;

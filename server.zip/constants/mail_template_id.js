const SendGridTemplates = {
  nftitem: "d-f5a4de8375934cf28bb8578a5ee6e8c6",//"d-e998b732bd0a4c068f93d2a350407c62",
  bundleitem: "d-1ee82c7a796e49938f60b13b8ea8b2b8",
};

module.exports = SendGridTemplates;
